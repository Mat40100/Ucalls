local AllEventHandlers = {}
local CombatLogHandlers = {}
local StatutFrame = CreateFrame("Frame")
local CombatFrame = CreateFrame("Frame")
local RefreshFrame = CreateFrame("Frame")

	local RefreshTime = 1
	local Delta = 0

	Options ={
		Calls = true,
		Creature = true,
		Player = true,
		CallTimer = 13,
		Random = false,
		Debug = true,
		InterruptBool = true,
		InterruptName = nil,
		InterruptExt = nil
	}

function CombatLogHandlers.PLAYER_ENTERING_WORLD(...)
	clientPlayer = Player:New()
	clientPlayer:SetName(UnitName("player"))

	CallUI:init()
	CallUI.AceGUI:Release(CallUI.mainFrame)

	Debug("Initialization", {
		["player name"] = clientPlayer:GetName(),
		["player count"] = clientPlayer:GetCounter(),
		["player row"] = clientPlayer:GetRow()
	})
end

function CombatLogHandlers.COMBAT_LOG_EVENT_UNFILTERED(event, ...)
	local timestamp, eventType, _, sourceGUID, sourceName, sourceFlags, sourceRaidFlags, destGUID, destName, destFlags, destRaidFlags = ...
	local spellId, spellName, spellSchool
	local amount, overkill, school, resisted, blocked, absorbed, critical, glancing, crushing, isOffHand

	if subEvent == "SWING_DAMAGE" then
		amount, overkill, school, resisted, blocked, absorbed, critical, glancing, crushing, isOffHand = select(12, ...)
	elseif subEvent == "SPELL_DAMAGE" then
		spellId, spellName, spellSchool, amount, overkill, school, resisted, blocked, absorbed, critical, glancing, crushing, isOffHand = select(12, ...)
	end

	if Options["Calls"] == true and Options["Random"] == true and eventType == "PARTY_KILL" and sourceName == clientPlayer:GetName() then
		RandomCalls:Controller(destGUID)

		return
	end

	if Options["Calls"] == true and Options["Random"] == false and eventType == "PARTY_KILL" and sourceName == clientPlayer:GetName() then
		Uclass:Controller(destGUID)

		return
	end

	if Options["InterruptBool"] == true and eventType == "SPELL_INTERRUPT" and sourceName == clientPlayer:GetName() then
		Debug("funct", "Interrupt event")
      local sourceSpell = select(9, ...)
      local targetSpell = select(12, ...)

			InterruptCalls:Controller(eventType ,sourceName, target, sourceSpell, targetSpell)

			return
	end

	if Options["InterruptBool"] == true and eventType == "SPELL_CAST_SUCCESS" and sourceName == clientPlayer:GetName() then
		local sourceSpell = select(9, ...)
		InterruptCalls:Controller(eventType, nil, target, sourceSpell)

		return
	end
end

function OnUpdate(elapsed)
	Delta = Delta + elapsed
	if (Delta > RefreshTime) then
		Uclass:Timer()
		Delta = 0
	end
end

-- HANDLERS --
for event , _ in pairs ( CombatLogHandlers ) do
	CombatFrame : RegisterEvent ( event )
end

CombatFrame : SetScript ("OnEvent", function ( self , event , ...)
	CombatLogHandlers[event](event, CombatLogGetCurrentEventInfo())
end)

RefreshFrame:SetScript("OnUpdate",function (self, elapsed)
	OnUpdate(elapsed)
end)
