RandomCalls = {}

function RandomCalls:Controller(destType)
  Debug("func","RandomCalls:Controller")

  if checkType(destType) then
    local tl = tablelength(randomSoundsList)
    Debug("Sound number", tl)

    if (tl == 0) then
      print("Ajoutez des sons !")

      return
    end

    k = math.random(1,tl)
    Uclass:SoundParser(k)

    return
  end
end
