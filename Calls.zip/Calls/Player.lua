Player = {
  Name = 0,
  Row = 0,
  Counter = 0,
}

function Player:New(v)
  v = v or {}
  setmetatable(v, self)
  self.__index = self
  return v
end

function Player:SetName(v)
  self.Name = v
end

function Player:GetName()
  return self.Name
end

function Player:SetRow(v)
  self.Row = v
end

function Player:GetRow()
  return self.Row
end

function Player:SetCounter(v)
  self.Counter = v
end

function Player:GetCounter()
  return self.Counter
end
