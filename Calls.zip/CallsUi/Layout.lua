Layout = {}
Layout.isShown = false
-- Callback function for OnGroupSelected
local function SelectGroup(container, event, group)
   container:ReleaseChildren()
  if group == "main" then
    MainUI:Init(container)
  elseif group == "random" then
    RandomUI:Init(container)
  elseif group == "list" then
    SoundList:Init(container)
  elseif group == "interrupt" then
    InterruptUI:Init(container)
  end
end

function Layout:Init()

  if Layout.isShown == true then
    Layout.frame:Release()
    Layout.isShown = false

    return
  end
  Layout.isShown = true
  -- Create the frame container
  Layout.frame = Libs.AceGUI:Create("Frame")
  Layout.frame:SetTitle("Calls")
  Layout.frame:SetCallback("OnClose", function(widget)
    Layout.isShown = false
    Libs.AceGUI:Release(widget) end)
  -- Fill Layout - the TabGroup widget will fill the whole frame
  Layout.frame:SetLayout("Fill")

  -- Create the TabGroup
  local tab =  Libs.AceGUI:Create("TabGroup")
  tab:SetLayout("Flow")
  -- Setup which tabs to show
  tab:SetTabs({{text="Général", value="main"}, {text="Aléatoire", value="random"}, {text="Liste des sons", value="list"}, {text="Interruptions", value="interrupt"}})
  -- Register callback
  tab:SetCallback("OnGroupSelected", SelectGroup)
  -- Set initial Tab (this will fire the OnGroupSelected callback)
  tab:SelectTab("main")

  -- add to the frame container
  Layout.frame:AddChild(tab)
end
