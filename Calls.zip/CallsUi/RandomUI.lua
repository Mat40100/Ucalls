RandomUI = {}

function RandomUI:addSound(soundName, soundExt)
  local s = tablelength(randomSoundsList)
  s = s + 1
  local sound = {
    name = soundName,
    ext = soundExt
  }
  table.insert(randomSoundsList, s , sound)

  Debug("check added sound", randomSoundsList)
end


function RandomUI:Init(container)

  local Check = Libs.AceGUI:Create("CheckBox")
  Check:SetLabel("Sons Aléatoires")
  Check:SetWidth(200)
  Check:SetValue(Options["Random"])
  Check:SetCallback("OnValueChanged", function(widget, event, value) Options["Random"] = value end)
  container:AddChild(Check)

  local SimpleGroup = Libs.AceGUI:Create("SimpleGroup")
        SimpleGroup:SetRelativeWidth(1)
        container:AddChild(SimpleGroup)

  local soundName = nil
  local soundExt = nil

  local nameBox = Libs.AceGUI:Create("EditBox")
      nameBox:SetLabel("Titre du son :")
      nameBox:SetWidth(100)
      nameBox:SetCallback("OnEnterPressed", function(widget, event, text) soundName = text end)
      SimpleGroup:AddChild(nameBox)

  local extBox = Libs.AceGUI:Create("EditBox")
      extBox:SetLabel("Extension du fichier son :")
      extBox:SetWidth(50)
      extBox:SetCallback("OnEnterPressed", function(widget, event, text) soundExt = text end)
      SimpleGroup:AddChild(extBox)

  local button = Libs.AceGUI:Create("Button")
        button:SetText("Ajouter")
        button:SetWidth(200)
        button:SetCallback("OnClick", function() RandomUI:addSound(soundName, soundExt) end)
  SimpleGroup:AddChild(button)
end
