Uclass = {}

local SoundsRow = {
	"firstblood",
	"doublekill",
	"multikill",
	"megakill",
	"ultrakill",
	"monsterkill"
}

local SoundsKill = {
	killingspree = 5,
	rampage = 10,
	dominating = 15,
	unstoppable = 20,
	godlike = 30
}

local TimerCounter = 0
local TimerRow = 0

function Uclass:Controller(destType)
	Debug("func", "Uclass:Controller")

	if checkType(destType) then
		Uclass:KillCounterInc()
		Uclass:RowCounterInc()
		Uclass:TimerReset()
		Uclass:SoundParser()

		return
	end
end

function Uclass:Timer()
	if clientPlayer:GetRow() > 0 then
		TimerCounter = TimerCounter + 1
	end
	if TimerCounter > Options["CallTimer"] then
		Uclass:TimerReset()
		Uclass:RowCounterReset()
	end
end

function Uclass:TimerReset()
	TimerCounter = 0
end

function Uclass:KillCounterInc()
	Debug("func", "Uclass:KillCounterInc")
	clientPlayer:SetCounter(clientPlayer:GetCounter() + 1)
	Debug("Counter", clientPlayer:GetCounter())
	if clientPlayer:GetCounter() > 30 then
		Uclass:KillCounterReset()
	end
end

function Uclass:KillCounterReset()
	Debug("func", "Uclass:KillCounterReset")
	clientPlayer:SetCounter(0)
	Debug("Reset", clientPlayer:GetCounter())
end

function Uclass:RowCounterReset()
	Debug("func", "Uclass:RowCounterReset")
	clientPlayer:SetRow(0)
	Debug("Reset", clientPlayer:GetRow())
end

function Uclass:RowCounterInc()
	Debug("func", "Uclass:RowCounterInc")
	clientPlayer:SetRow(clientPlayer:GetRow() + 1)
end

function Uclass:SoundParser(soundIndex)
	local allreadyPlay = false
	if (Options["Random"] == true ) then
	 	local sound = randomSoundsList[soundIndex]["name"].."."..randomSoundsList[soundIndex]["ext"]
		Debug("func", "Uclass:SoundParser  -> "..randomSoundsList[soundIndex]["name"])
		PlaySoundFile("Interface\\AddOns\\Calls\\Sounds\\"..randomSoundsList[soundIndex]["name"].."."..randomSoundsList[soundIndex]["ext"], "Master")
		allreadyPlay = true
	end
	for k, v in pairs(SoundsKill) do
		if (SoundsKill[k] == clientPlayer:GetCounter()) and (clientPlayer:GetCounter() < 31 ) and (allreadyPlay==false) then
			Debug("func", "Uclass:SoundParser -> "..k)
			PlaySoundFile("Interface\\AddOns\\Calls\\Calls\\"..k..".ogg", "Master")
			allreadyPlay = true
		end
	end
	if (clientPlayer:GetRow() ~= 0) and (clientPlayer:GetRow() < 7) and (allreadyPlay==false) then
		Debug("func", "Uclass:SoundParser -> "..SoundsRow[clientPlayer:GetRow()])
		PlaySoundFile("Interface\\AddOns\\Calls\\Calls\\"..SoundsRow[clientPlayer:GetRow()]..".ogg", "Master")
	end
	allreadyPlay = false
end
