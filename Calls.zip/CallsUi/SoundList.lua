SoundList = {}

function SoundList:deleteSound(soundIndex)
  table.remove(randomSoundsList, soundIndex)
  Debug("Sounds", randomSoundsList)
end

function SoundList:deleteSecure(soundIndex, widget,container)
  SoundList.comfirm = Libs.AceGUI:Create("Frame")
  SoundList.comfirm:SetTitle("Are you sure ?")
  SoundList.comfirm:SetStatusText("Deleting : "..randomSoundsList[soundIndex]["name"])
  SoundList.comfirm:SetHeight(100)
  SoundList.comfirm:SetCallback("OnClose", function(widget) Libs.AceGUI:Release(widget) end)

  local secureButton = Libs.AceGUI:Create("Button")
  secureButton:SetText("Yes")
  secureButton:SetWidth(200)
  secureButton:SetCallback("OnClick", function()
    SoundList:deleteSound(soundIndex)
    SoundList.comfirm:Release()
    container:ReleaseChildren()
    SoundList:Init(container)
  end)
  SoundList.comfirm:AddChild(secureButton)
end

function SoundList:trySound(soundIndex)
  Debug("func", "trySound")
  Debug("Sound Name", randomSoundsList[soundIndex]["name"])
  PlaySoundFile("Interface\\AddOns\\Calls\\Sounds\\"..randomSoundsList[soundIndex]["name"].."."..randomSoundsList[soundIndex]["ext"], "Master")
end

function SoundList:Init(container)
  SoundList:Create(container)
end

function SoundList:Create(container)
  innerFrame = Libs.AceGUI:Create("SimpleGroup")
  container:AddChild(innerFrame)
  SoundList:Refresh(innerFrame,container)
end

function SoundList:Refresh(widget,container)

  for k,var in pairs(randomSoundsList) do
    local sound = Libs.AceGUI:Create("InteractiveLabel")
    local v = (var["name"].."."..var["ext"])
    sound:SetText(v)
    sound:SetRelativeWidth(1)
    sound:SetCallback("OnEnter", function(widget) widget:SetColor(255,0,0) end)
    sound:SetCallback("OnLeave", function(widget) widget:SetColor(255,255,255) end)
    sound:SetCallback("OnClick", function(widget, event, btn)
      if (btn == "LeftButton") then
        SoundList:deleteSecure(k, widget,container)
      end
      if (btn == "RightButton") then
        SoundList:trySound(k)
      end
    end)
    widget:AddChild(sound)
  end
end
