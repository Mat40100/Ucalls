function Debug(m, v)
  --[[ this tool allow player to debug module by module or all at the same time,
  the goal is not to flood chat ]]
  if (Options["Debug"] == true) then
    if (m == "func") then
      print ("Function called : ", v)
      return
    end

    print("Start debug : ", m)
    print("[type] => ", type(v))
    if (type(v) == "table") then
      for k,var in pairs(v) do
        if (type(var) == "table") then
          Debug("inner_Table", var)
        else
          print("__"..k," => "..var)
        end
      end
    end

    if (type(v) == "string") then
      print("__", v)
    end

    if (type(v) == "boolean") then
      print("__", v)
    end

    if (type(v) == "number") then
      print("__", v)
    end

    if (type(v) == "function") then
      ---------
    end

    print ("End debug : ", m)
  end
end

function tablelength(T)
  local count = 0
  for _ in pairs(T) do count = count + 1 end
  return count
end

function tableContains(table, item)
  for k, var in pairs(table) do
    if k == item then

      return true
    end
  end

  return false
end

function checkType(guid)

  local destType, _ = strsplit("-", guid , 2)

  Debug("Openent type :", destType)
	for k,v in pairs(Options) do
		Debug("Testing options :", k)
		if (string.find(destType, k) ~= nil) and Options[k] == true then
			Debug("checkType", "True on"..destType)

			return true
		end
	end
	Debug("checkType", "False on all")
end
--[[



if bit.band(UnitFlag, COMBATLOG_OBJECT_CONTROL_PLAYER) > 0 then
  UnitFlag = "Player"
end

if bit.band(UnitFlag, COMBATLOG_OBJECT_CONTROL_NPC) > 0 then
  UnitFlag = "Creature"
end

if bit.band(UnitFlag, COMBATLOG_OBJECT_CONTROL_PET) > 0 then
  UnitFlag = "Pet"
end
]]
