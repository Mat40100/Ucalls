InterruptCalls = {}

InterruptCalls.spellList = {
  [6552] = 10,-- 6552  Pummel
  [2139] = 24,-- 2139  Counterspell
  [19647] = 24,-- 19647 Spell Lock
  [16979] = 15,-- 16979 Feral Charge
  [1766] = 10,-- 1766  Kick
  [47528] = 10,-- 47528 Mind Freeze
  [5211] = 60,-- 5211  Bash
  [15487] = 45,-- 15487 Silence
  [64044] = 120,-- 64044 Psychic Horror
  [34490] = 20,-- 34490 Silencing Shot
  [47476] = 120,-- 47476 Strangulate
  [20066] = 60,-- 20066 Repentance
  [853] = 60-- 853   Hammer of Justice
}

function InterruptCalls:Controller (eventType, ...)
  Debug("func","InterruptCalls:Controller")

  if eventType == "SPELL_CAST_SUCCESS" then
    local target = select(2,...)
    local sourceSpell = select(3,...)
    --Debug("inttrupt list", InterruptCalls.spellList)
    if tableContains(InterruptCalls.spellList, sourceSpell) then
      Debug("Interrupt spell found", sourceSpell)
      InterruptCalls:Play(Options["InterruptName"], Options["InterruptExt"])
    end
  end

  if eventType == "SPELL_INTERRUPT" then
    local sourceName = select(1,...)
    local targetSpell = select(4,...)

    if Options["Interrupt"]["name"] ~= nil then
      InterruptCalls:Play(Options["InterruptName"], Options["InterruptExt"])

      return
    end
  end

  Debug("No Interrupt sounds", "") ]]
end

function InterruptCalls:Play(soundName, soundExt)
  Debug("func", "Player  -> "..soundName)
  PlaySoundFile("Interface\\AddOns\\Calls\\Sounds\\"..soundName.."."..soundExt , "Master")
end
