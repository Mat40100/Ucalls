SLASH_BOOLCALL1 = "/Calls"
SLASH_CALLTIMER1 = "/CallTimer"

SlashCmdList["BOOLCALL"] = function(msg)
	Layout:Init()
end
