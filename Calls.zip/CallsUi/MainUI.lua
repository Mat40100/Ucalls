MainUI = {}

function MainUI:Init(container)

  local SimpleGroup = Libs.AceGUI:Create("SimpleGroup")
        SimpleGroup:SetRelativeWidth(1)
        container:AddChild(SimpleGroup)

  local callsCheck = Libs.AceGUI:Create("CheckBox")
  callsCheck:SetLabel("Activer les sons")
  callsCheck:SetWidth(200)
  callsCheck:SetValue(Options["Calls"])
  callsCheck:SetCallback("OnValueChanged", function(widget, event, value) Options["Calls"] = value end)
  SimpleGroup:AddChild(callsCheck)

  local npcCheck = Libs.AceGUI:Create("CheckBox")
  npcCheck:SetLabel("Sons pour les créatures")
  npcCheck:SetWidth(200)
  npcCheck:SetValue(Options["Creature"])
  npcCheck:SetCallback("OnValueChanged", function(widget, event, value) Options["Creature"] = value end)
  SimpleGroup:AddChild(npcCheck)

  local playerCheck = Libs.AceGUI:Create("CheckBox")
  playerCheck:SetLabel("Sons pour les joueurs")
  playerCheck:SetWidth(200)
  playerCheck:SetValue(Options["Player"])
  playerCheck:SetCallback("OnValueChanged", function(widget, event, value) Options["Player"] = value end)
  SimpleGroup:AddChild(playerCheck)

  local debugCheck = Libs.AceGUI:Create("CheckBox")
  debugCheck:SetLabel("Debugger")
  debugCheck:SetWidth(200)
  debugCheck:SetValue(Options["Debug"])
  debugCheck:SetCallback("OnValueChanged", function(widget, event, value) Options["Debug"] = value end)
  SimpleGroup:AddChild(debugCheck)

  local timerSlider = Libs.AceGUI:Create("Slider")
  timerSlider:SetLabel("Temps de reset pour les séries meurtrières")
  timerSlider:SetWidth(200)
  timerSlider:SetValue(Options["CallTimer"])
  timerSlider:SetSliderValues(0,25,1)
  timerSlider:SetCallback("OnMouseUp", function(widget, event, value) Options["CallTimer"] = value end)
  container:AddChild(timerSlider)
end
