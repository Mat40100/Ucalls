InterruptUI = {}

function InterruptUI:Init(container)
  local callsCheck = Libs.AceGUI:Create("CheckBox")
  callsCheck:SetLabel("Son sur interruption")
  callsCheck:SetWidth(200)
  callsCheck:SetValue(Options["InterruptBool"])
  callsCheck:SetCallback("OnValueChanged", function(widget, event, value) Options["InterruptBool"] = value end)
  container:AddChild(callsCheck)

  local soundName = nil
  local soundExt = nil

  if Options["InterruptName"] ~= nil then
    local label = Libs.AceGUI:Create("Label")
          v = "Son actuel => "..Options["InterruptName"]
          label:SetText(v)
          label:SetRelativeWidth(1)
          container:AddChild(label)
  end

  local nameBox = Libs.AceGUI:Create("EditBox")
      nameBox:SetLabel("Titre du son :")
      nameBox:SetWidth(200)
      nameBox:SetCallback("OnEnterPressed", function(widget, event, text) soundName = text end)
      container:AddChild(nameBox)

  local extBox = Libs.AceGUI:Create("EditBox")
      extBox:SetLabel("Extension du fichier son :")
      extBox:SetWidth(200)
      extBox:SetCallback("OnEnterPressed", function(widget, event, text) soundExt = text end)
      container:AddChild(extBox)

  local button = Libs.AceGUI:Create("Button")
        button:SetText("Ajouter")
        button:SetWidth(200)
        button:SetCallback("OnClick", function()
          InterruptUI:addSound(soundName, soundExt)
          InterruptUI:Refresh(container)
        end)
        container:AddChild(button)
end

function InterruptUI:addSound(soundName, soundExt)
  Options["InterruptName"] = soundName
  Options["InterruptExt"] = soundExt
  Debug("Interrupt sound now => ", Options["InterruptName"])
end

function InterruptUI:Refresh(container)
  container:ReleaseChildren()
  InterruptUI:Init(container)
end
