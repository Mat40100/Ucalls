Libs = {}

Libs.AceGUI = LibStub("AceGUI-3.0")
Libs.MyAddon = LibStub("AceAddon-3.0"):NewAddon("MyAddon")
